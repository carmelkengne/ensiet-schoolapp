import Bulletin from '../components/Bulletin';

export default function BulletinPage() {
  return <Bulletin eleveId={1} />;
}
